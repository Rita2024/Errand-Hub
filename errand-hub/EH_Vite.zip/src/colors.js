const colors = {
    primary: '#fbf7f4',
    active: '#eee6e2',
    iconColor: '#f5a147',
  }
  export default colors